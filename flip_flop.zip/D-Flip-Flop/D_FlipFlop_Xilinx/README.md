:star: D flip-flop characteristic table : 
|Inputs|Output|Status|
|:---:|:---:|:---:|
|D|Q \| Q'|----|
|0|0 \| 1 |Reset|
|1|1 \| 0 |Set|
